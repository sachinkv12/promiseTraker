// const { default: mongoose } = require("mongoose");

const { json } = require("express");
const Register=(require('../modules/Register'))
const express=require('express');
const mongoose=require('mongoose');
const Router = express.Router();
const bcrypt = require('bcrypt')

Router.post('/registration',async(req,res) =>{
    const{name,mobilenumber,email,password}=req.body;

try{
    const existinguser= await Register.findOne({email:email}) ;
    if(existinguser){
        return res.status(400).json({message:'already registerd'})
    }
const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newRegister = new Register({
      name,
      mobilenumber,
      email,
      password: hashedPassword,
    });
    await newRegister.save();
     res.status(201).json({message:'registration successfuly'})
}
catch (error){
    console.error(error)
    res.status(500).json({message:'server error'})
}

});

module.exports=Router;