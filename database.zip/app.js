const express = require('express');
const mongoose = require('mongoose');
const Registrationroutes=require('./Routes/Registrationroutes')
const Signinroutes=require('./Routes/Signinroutes')
const app = express();
const PORT=5000;
mongoose.connect('mongodb+srv://sachin:Project@cluster0.wxz5dsc.mongodb.net/?retryWrites=true&w=majority')
.then(()=> console.log("connected successfuly"))
.catch(err=> console.error("field connection",err));
app.use(express.json());
app.use('/api',Registrationroutes);
app.use('/api',Signinroutes);

app.listen(PORT,()=>{
    console.log(`server is runinng on http://localhost:${PORT}`)
})  
module.exports=app;